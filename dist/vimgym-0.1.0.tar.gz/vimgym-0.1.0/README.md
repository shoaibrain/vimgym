# Vimgym

AI session memory for developers. Local. Fast. No cloud.

`git log` for your Claude Code sessions.
