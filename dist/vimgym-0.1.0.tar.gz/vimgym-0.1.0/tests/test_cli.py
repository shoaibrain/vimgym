import subprocess
import sys


def run(args):
    return subprocess.run(
        [sys.executable, "-m", "vimgym.cli"] + args,
        capture_output=True, text=True
    )


def test_version():
    r = run(["--version"])
    assert r.returncode == 0
    assert "0.1.0" in r.stdout


def test_help():
    r = run(["--help"])
    assert r.returncode == 0
    assert "start" in r.stdout
    assert "search" in r.stdout


def test_status_runs(tmp_path, monkeypatch):
    # Point at an isolated vault so we don't touch the user's real one.
    monkeypatch.setenv("VIMGYM_PATH", str(tmp_path))
    r = run(["status"])
    assert r.returncode == 0
    assert "stopped" in r.stdout or "running" in r.stdout


def test_stop_when_not_running(tmp_path, monkeypatch):
    monkeypatch.setenv("VIMGYM_PATH", str(tmp_path))
    r = run(["stop"])
    assert r.returncode == 0
    assert "not running" in r.stdout or "stopped" in r.stdout


def test_open_when_not_running(tmp_path, monkeypatch):
    monkeypatch.setenv("VIMGYM_PATH", str(tmp_path))
    r = run(["open"])
    assert r.returncode == 1
    assert "not running" in r.stdout


def test_search_requires_query(tmp_path, monkeypatch):
    monkeypatch.setenv("VIMGYM_PATH", str(tmp_path))
    r = run(["search"])
    assert r.returncode == 2
