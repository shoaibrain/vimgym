"""Schema migration: v1 → v2.

Adds `source_id` to the sessions table so every session knows which AI tool
produced it. All existing rows are backfilled with `claude_code` (the only
v1 source). Idempotent.
"""
from __future__ import annotations

import sqlite3


def _has_column(conn: sqlite3.Connection, table: str, column: str) -> bool:
    rows = conn.execute(f"PRAGMA table_info({table})").fetchall()
    # PRAGMA table_info returns: (cid, name, type, notnull, dflt_value, pk)
    return any(r[1] == column for r in rows)


def up(conn: sqlite3.Connection) -> None:
    """Add source_id column. Safe to call multiple times."""
    if not _has_column(conn, "sessions", "source_id"):
        conn.execute(
            "ALTER TABLE sessions ADD COLUMN source_id TEXT DEFAULT 'claude_code'"
        )

    conn.execute(
        "UPDATE sessions SET source_id = 'claude_code' WHERE source_id IS NULL"
    )

    conn.execute(
        "INSERT OR REPLACE INTO config (key, value) VALUES ('schema_version', '2')"
    )

    # Helpful index for future per-source filtering.
    conn.execute(
        "CREATE INDEX IF NOT EXISTS idx_sessions_source ON sessions(source_id)"
    )

    conn.commit()


def down(conn: sqlite3.Connection) -> None:
    """SQLite < 3.35 lacks DROP COLUMN; v1's only "down" path is metadata-only."""
    conn.execute(
        "INSERT OR REPLACE INTO config (key, value) VALUES ('schema_version', '1')"
    )
    conn.commit()
